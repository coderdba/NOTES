hostnamectl set-hostname oel7k8smodel
