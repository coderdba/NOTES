![RacAttack 12cR1 at home](http://upload.wikimedia.org/wikipedia/commons/8/8b/Racattack12c-book-title.png)

Work in progress at RACATTACK NINJA HQ

Nothing to see as we are good ninjas

In the meantime, have a look to the official [racattack 12cR1 lab](http://en.wikibooks.org/wiki/RAC_Attack_-_Oracle_Cluster_Database_at_Home/RAC_Attack_12c/Print_Book)



Alvaro.

